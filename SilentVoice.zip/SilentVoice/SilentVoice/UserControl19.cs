﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SilentVoice
{
    public partial class UserControl19 : UserControl
    {
        private static UserControl19 _instance;

        public static UserControl19 Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new UserControl19();
                }
                return _instance;
            }
        }
        public UserControl19()
        {
            InitializeComponent();
        }

        private void UserControl19_Load(object sender, EventArgs e)
        {

        }
    }
}
