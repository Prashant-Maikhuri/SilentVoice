﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SilentVoice
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        int flag1 = 0;
        private void button1_Click(object sender, EventArgs e)
        {

            if (!panel1.Controls.Contains(UserControl1.Instance))
            {
                panel1.Controls.Add(UserControl1.Instance);
                UserControl1.Instance.Dock = DockStyle.Fill;
                UserControl1.Instance.BringToFront();
                flag1 = 1;
            }

            else
            {
                UserControl1.Instance.BringToFront();
                flag1 = 0;
            }


        }

        private void button19_Click(object sender, EventArgs e)
        {
            Form4 obj = new Form4();
            this.Hide();
            obj.Show();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

            if (!panel1.Controls.Contains(UserControl2.Instance))
            {
                panel1.Controls.Add(UserControl2.Instance);
                UserControl2.Instance.Dock = DockStyle.Fill;
                UserControl2.Instance.BringToFront();
            }

            else
            {
                UserControl2.Instance.BringToFront();
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (!panel1.Controls.Contains(UserControl3.Instance))
            {
                panel1.Controls.Add(UserControl3.Instance);
                UserControl3.Instance.Dock = DockStyle.Fill;
                UserControl3.Instance.BringToFront();
            }

            else
            {
                UserControl3.Instance.BringToFront();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (!panel1.Controls.Contains(UserControl4.Instance))
            {
                panel1.Controls.Add(UserControl4.Instance);
                UserControl4.Instance.Dock = DockStyle.Fill;
                UserControl4.Instance.BringToFront();
            }

            else
            {
                UserControl4.Instance.BringToFront();
            }

        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (!panel1.Controls.Contains(UserControl5.Instance))
            {
                panel1.Controls.Add(UserControl5.Instance);
                UserControl5.Instance.Dock = DockStyle.Fill;
                UserControl5.Instance.BringToFront();
            }

            else
            {
                UserControl5.Instance.BringToFront();
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (!panel1.Controls.Contains(UserControl6.Instance))
            {
                panel1.Controls.Add(UserControl6.Instance);
                UserControl6.Instance.Dock = DockStyle.Fill;
                UserControl6.Instance.BringToFront();
            }

            else
            {
                UserControl6.Instance.BringToFront();
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (!panel1.Controls.Contains(UserControl7.Instance))
            {
                panel1.Controls.Add(UserControl7.Instance);
                UserControl7.Instance.Dock = DockStyle.Fill;
                UserControl7.Instance.BringToFront();
            }

            else
            {
                UserControl7.Instance.BringToFront();
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (!panel1.Controls.Contains(UserControl8.Instance))
            {
                panel1.Controls.Add(UserControl8.Instance);
                UserControl8.Instance.Dock = DockStyle.Fill;
                UserControl8.Instance.BringToFront();
            }

            else
            {
                UserControl8.Instance.BringToFront();
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (!panel1.Controls.Contains(UserControl9.Instance))
            {
                panel1.Controls.Add(UserControl9.Instance);
                UserControl9.Instance.Dock = DockStyle.Fill;
                UserControl9.Instance.BringToFront();
            }

            else
            {
                UserControl9.Instance.BringToFront();
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (!panel1.Controls.Contains(UserControl10.Instance))
            {
                panel1.Controls.Add(UserControl10.Instance);
                UserControl10.Instance.Dock = DockStyle.Fill;
                UserControl10.Instance.BringToFront();
            }

            else
            {
                UserControl10.Instance.BringToFront();
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (!panel1.Controls.Contains(UserControl11.Instance))
            {
                panel1.Controls.Add(UserControl11.Instance);
                UserControl11.Instance.Dock = DockStyle.Fill;
                UserControl11.Instance.BringToFront();
            }

            else
            {
                UserControl11.Instance.BringToFront();
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (!panel1.Controls.Contains(UserControl12.Instance))
            {
                panel1.Controls.Add(UserControl12.Instance);
                UserControl12.Instance.Dock = DockStyle.Fill;
                UserControl12.Instance.BringToFront();
            }

            else
            {
                UserControl12.Instance.BringToFront();
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (!panel1.Controls.Contains(UserControl13.Instance))
            {
                panel1.Controls.Add(UserControl13.Instance);
                UserControl13.Instance.Dock = DockStyle.Fill;
                UserControl13.Instance.BringToFront();
            }

            else
            {
                UserControl13.Instance.BringToFront();
            }

        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (!panel1.Controls.Contains(UserControl14.Instance))
            {
                panel1.Controls.Add(UserControl14.Instance);
                UserControl14.Instance.Dock = DockStyle.Fill;
                UserControl14.Instance.BringToFront();
            }

            else
            {
                UserControl14.Instance.BringToFront();
            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            if (!panel1.Controls.Contains(UserControl15.Instance))
            {
                panel1.Controls.Add(UserControl15.Instance);
                UserControl15.Instance.Dock = DockStyle.Fill;
                UserControl15.Instance.BringToFront();
            }

            else
            {
                UserControl15.Instance.BringToFront();
            }

        }

        private void button16_Click(object sender, EventArgs e)
        {
            if (!panel1.Controls.Contains(UserControl16.Instance))
            {
                panel1.Controls.Add(UserControl16.Instance);
                UserControl16.Instance.Dock = DockStyle.Fill;
                UserControl16.Instance.BringToFront();
            }

            else
            {
                UserControl16.Instance.BringToFront();
            }

        }

        private void button17_Click(object sender, EventArgs e)
        {
            if (!panel1.Controls.Contains(UserControl17.Instance))
            {
                panel1.Controls.Add(UserControl17.Instance);
                UserControl17.Instance.Dock = DockStyle.Fill;
                UserControl17.Instance.BringToFront();
            }

            else
            {
                UserControl17.Instance.BringToFront();
            }
        }

        private void button18_Click(object sender, EventArgs e)
        {
            if (!panel1.Controls.Contains(UserControl18.Instance))
            {
                panel1.Controls.Add(UserControl18.Instance);
                UserControl18.Instance.Dock = DockStyle.Fill;
                UserControl18.Instance.BringToFront();
            }

            else
            {
                UserControl18.Instance.BringToFront();
            }
        }

        private void button20_Click(object sender, EventArgs e)
        {
            Form2 obj = new Form2();
            this.Hide();
            obj.Show();
        }
    }
}
