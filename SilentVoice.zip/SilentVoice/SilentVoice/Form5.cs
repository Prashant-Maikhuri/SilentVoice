﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SilentVoice
{
    public partial class Form5 : Form
    {
        
        public Form5()
        {
            InitializeComponent();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            axWindowsMediaPlayer1.URL = (@"D:\Hello\hello-5.mp4");
            axWindowsMediaPlayer1.Ctlcontrols.play();




        }

        private void axWindowsMediaPlayer1_Enter(object sender, EventArgs e)
        {
            
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            axWindowsMediaPlayer1.URL = (@"D:\Hello\Sorry.mp4");
            axWindowsMediaPlayer1.Ctlcontrols.play();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            axWindowsMediaPlayer1.URL = (@"D:\Hello\thankyou4.mp4");
            axWindowsMediaPlayer1.Ctlcontrols.play();
        }

        private void button20_Click(object sender, EventArgs e)
        {
            Form2 obj = new Form2();
            this.Hide();
            obj.Show();
        }

        private void Form5_Load(object sender, EventArgs e)
        {

        }
    }
}
