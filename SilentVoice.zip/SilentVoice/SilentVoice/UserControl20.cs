﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SilentVoice
{
    public partial class UserControl20 : UserControl
    {
        private static UserControl20 _instance;

        public static UserControl20 Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new UserControl20();
                }
                return _instance;
            }
        }
        public UserControl20()
        {
            InitializeComponent();
        }

        private void UserControl20_Load(object sender, EventArgs e)
        {

        }
    }
}
