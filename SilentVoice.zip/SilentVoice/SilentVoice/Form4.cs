﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SilentVoice
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!panel1.Controls.Contains(UserControl19.Instance))
            {
                panel1.Controls.Add(UserControl19.Instance);
                UserControl19.Instance.Dock = DockStyle.Fill;
                UserControl19.Instance.BringToFront();
            }

            else
            {
                UserControl19.Instance.BringToFront();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (!panel1.Controls.Contains(UserControl20.Instance))
            {
                panel1.Controls.Add(UserControl20.Instance);
                UserControl20.Instance.Dock = DockStyle.Fill;
                UserControl20.Instance.BringToFront();
            }

            else
            {
                UserControl20.Instance.BringToFront();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (!panel1.Controls.Contains(UserControl21.Instance))
            {
                panel1.Controls.Add(UserControl21.Instance);
                UserControl21.Instance.Dock = DockStyle.Fill;
                UserControl21.Instance.BringToFront();
            }

            else
            {
                UserControl21.Instance.BringToFront();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (!panel1.Controls.Contains(UserControl22.Instance))
            {
                panel1.Controls.Add(UserControl22.Instance);
                UserControl22.Instance.Dock = DockStyle.Fill;
                UserControl22.Instance.BringToFront();
            }

            else
            {
                UserControl22.Instance.BringToFront();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (!panel1.Controls.Contains(UserControl23.Instance))
            {
                panel1.Controls.Add(UserControl23.Instance);
                UserControl23.Instance.Dock = DockStyle.Fill;
                UserControl23.Instance.BringToFront();
            }

            else
            {
                UserControl23.Instance.BringToFront();
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (!panel1.Controls.Contains(UserControl24.Instance))
            {
                panel1.Controls.Add(UserControl24.Instance);
                UserControl24.Instance.Dock = DockStyle.Fill;
                UserControl24.Instance.BringToFront();
            }

            else
            {
                UserControl24.Instance.BringToFront();
            }
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (!panel1.Controls.Contains(UserControl25.Instance))
            {
                panel1.Controls.Add(UserControl25.Instance);
                UserControl25.Instance.Dock = DockStyle.Fill;
                UserControl25.Instance.BringToFront();
            }

            else
            {
                UserControl25.Instance.BringToFront();
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (!panel1.Controls.Contains(UserControl26.Instance))
            {
                panel1.Controls.Add(UserControl26.Instance);
                UserControl26.Instance.Dock = DockStyle.Fill;
                UserControl26.Instance.BringToFront();
            }

            else
            {
                UserControl26.Instance.BringToFront();
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Form2 obj = new Form2();
            this.Hide();
            obj.Show();
        }

        private void button19_Click(object sender, EventArgs e)
        {
            Form3 obj = new Form3();
            this.Hide();
            obj.Show();
        }
    }
}
