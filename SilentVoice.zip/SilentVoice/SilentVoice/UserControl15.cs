﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SilentVoice
{
    public partial class UserControl15 : UserControl
    {
        private static UserControl15 _instance;

        public static UserControl15 Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new UserControl15();
                }
                return _instance;
            }
        }
        public UserControl15()
        {
            InitializeComponent();
        }

        private void UserControl15_Load(object sender, EventArgs e)
        {

        }
    }
}
