﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SilentVoice
{
    public partial class UserControl26 : UserControl
    {
        private static UserControl26 _instance;

        public static UserControl26 Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new UserControl26();
                }
                return _instance;
            }
        }
        public UserControl26()
        {
            InitializeComponent();
        }

        private void UserControl26_Load(object sender, EventArgs e)
        {

        }
    }
}
