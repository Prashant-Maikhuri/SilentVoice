﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SilentVoice
{
    public partial class UserControl22 : UserControl
    {
        private static UserControl22 _instance;

        public static UserControl22 Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new UserControl22();
                }
                return _instance;
            }
        }
        public UserControl22()
        {
            InitializeComponent();
        }

        private void UserControl22_Load(object sender, EventArgs e)
        {

        }
    }
}
