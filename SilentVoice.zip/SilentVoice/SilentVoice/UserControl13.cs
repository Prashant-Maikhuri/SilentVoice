﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SilentVoice
{
    public partial class UserControl13 : UserControl
    {
        private static UserControl13 _instance;

        public static UserControl13 Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new UserControl13();
                }
                return _instance;
            }
        }
        public UserControl13()
        {
            InitializeComponent();
        }

        private void UserControl13_Load(object sender, EventArgs e)
        {

        }
    }
}
